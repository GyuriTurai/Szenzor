﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.IO;
using LiteDB; // LiteDB használata

namespace SzenzorHalozat
{
    // Szenzor típus enum
    public enum SzenzorTipus
    {
        Homerseklet,
        Paratartalom,
        Vizszint
    }

    // Szenzor osztály
    public class Szenzor
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public SzenzorTipus Tipus { get; set; }
        public double Ertek { get; set; }
        public DateTime MeresiIdo { get; set; }
    }

    class Program
    {
        // Esemény delegált definiálása
        public delegate void MeresKeszDelegate(Szenzor szenzor);
        public static event MeresKeszDelegate MeresKesz;

        static void Main(string[] args)
        {
            // Adatbázis inicializálása
            using (var db = new LiteDatabase(@"SzenzorAdatok.db"))
            {
                var szenzorAdatok = db.GetCollection<Szenzor>("szenzorAdatok");

                // Adatok törlése az új futtatás előtt
                szenzorAdatok.DeleteAll();

                // Szenzorok létrehozása
                List<Szenzor> szenzorok = new List<Szenzor>
                {
                    new Szenzor { Id = 1, Nev = "H1", Tipus = SzenzorTipus.Homerseklet, Ertek = VeletlenErtek(0, 35), MeresiIdo = DateTime.Now },
                    new Szenzor { Id = 2, Nev = "P1", Tipus = SzenzorTipus.Paratartalom, Ertek = VeletlenErtek(30, 90), MeresiIdo = DateTime.Now },
                    new Szenzor { Id = 3, Nev = "V1", Tipus = SzenzorTipus.Vizszint, Ertek = VeletlenErtek(0, 100), MeresiIdo = DateTime.Now }
                };

                // Esemény feliratkozás
                MeresKesz += szenzor => Console.WriteLine($"Új mérés: {szenzor.Nev} ({szenzor.Tipus}) - {szenzor.Ertek} mért érték ({szenzor.MeresiIdo})");

                // Adatok hozzáadása az adatbázishoz és események kiváltása
                foreach (var szenzor in szenzorok)
                {
                    szenzorAdatok.Insert(szenzor);
                    MeresKesz?.Invoke(szenzor);
                }

                // LINQ-lekérdezések

                // 1. Hőmérséklet szenzor leolvasások listázása
                var homersekletLeolvasasok = szenzorAdatok.Find(s => s.Tipus == SzenzorTipus.Homerseklet);
                Console.WriteLine("\nHőmérséklet szenzor leolvasások:");
                foreach (var szenzor in homersekletLeolvasasok)
                {
                    Console.WriteLine($"{szenzor.Nev}: {szenzor.Ertek} °C ({szenzor.MeresiIdo})");
                }

                // 2. Átlagos érték kiszámítása szenzor típusonként
                var atlagErtekek = szenzorAdatok
                    .FindAll()
                    .GroupBy(s => s.Tipus)
                    .Select(g => new { Tipus = g.Key, Atlag = g.Average(s => s.Ertek) });

                Console.WriteLine("\nÁtlagos értékek szenzor típusonként:");
                foreach (var atlag in atlagErtekek)
                {
                    Console.WriteLine($"{atlag.Tipus}: {atlag.Atlag:F2}");
                }

                // 3. Legutóbbi leolvasások minden szenzorra
                var legutobbiLeolvasasok = szenzorAdatok
                    .FindAll()
                    .GroupBy(s => s.Nev)
                    .Select(g => g.OrderByDescending(s => s.MeresiIdo).First());

                Console.WriteLine("\nLegutóbbi leolvasások:");
                foreach (var szenzor in legutobbiLeolvasasok)
                {
                    Console.WriteLine($"{szenzor.Nev}: {szenzor.Ertek} ({szenzor.MeresiIdo})");
                }

                // Mérési adatok exportálása JSON fájlba
                string json = JsonConvert.SerializeObject(szenzorAdatok.FindAll(), Formatting.Indented);
                File.WriteAllText("szenzor_adatok.json", json);
                Console.WriteLine("\nA mérési adatok sikeresen ki lettek exportálva a 'szenzor_adatok.json' fájlba.");
            }
            Console.ReadKey();
        }
        

        // Véletlen érték generálása adott tartományban
        static double VeletlenErtek(double min, double max)
        {
            Random rand = new Random();
            return Math.Round(rand.NextDouble() * (max - min) + min, 2);
        }
        
    }
    
}
